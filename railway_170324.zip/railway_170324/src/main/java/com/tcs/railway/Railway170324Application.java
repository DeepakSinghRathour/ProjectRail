package com.tcs.railway;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Railway170324Application {

	public static void main(String[] args) {
		SpringApplication.run(Railway170324Application.class, args);
	}

}
