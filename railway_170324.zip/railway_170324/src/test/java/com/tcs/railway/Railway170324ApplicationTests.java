package com.tcs.railway;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Railway170324ApplicationTests {

	@Test
	void contextLoads() {
	}

}
